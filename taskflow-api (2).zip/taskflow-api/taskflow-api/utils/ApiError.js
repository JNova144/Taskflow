/**
 * Error personalizado para la API, con código de estado HTTP explícito.
 * Se lanza desde los controladores y lo captura el middleware de errores.
 */
class ApiError extends Error {
  constructor(statusCode, message) {
    super(message);
    this.statusCode = statusCode;
    this.name = "ApiError";
  }
}

module.exports = ApiError;