const mongoose = require("mongoose");
const ApiError = require("./ApiError");

/**
 * Lanza un 400 si el id recibido por params no tiene formato válido de ObjectId,
 * en vez de dejar que Mongoose lo convierta en un CastError más adelante.
 */

function validateObjectId(id) {
  if (!mongoose.Types.ObjectId.isValid(id)) {
    throw new ApiError(400, `Id inválido: "${id}"`);
  }
}

module.exports = validateObjectId;