/**
 * Envuelve un controlador async para capturar cualquier error
 * y pasarlo automáticamente a next(), sin repetir try/catch
 * en cada función del controlador.
 */
function catchAsync(fn) {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

module.exports = catchAsync;