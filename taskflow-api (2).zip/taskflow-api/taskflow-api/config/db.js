const dns = require("dns");
dns.setServers(["8.8.8.8", "1.1.1.1"]);

const mongoose = require("mongoose");

async function connectDB() {
  const uri = process.env.MONGODB_URI;
  const dbName = process.env.DB_NAME || "tasksflow";

  if (!uri) {
    throw new Error("Falta la variable de entorno MONGODB_URI. Revisa tu archivo .env");
  }

  mongoose.set("strictQuery", true);

  await mongoose.connect(uri, {
    dbName,
    maxPoolSize: 10,
    serverSelectionTimeoutMS: 10000
  });

  console.log(`MongoDB conectado -> base de datos: "${dbName}"`);

  mongoose.connection.on("error", (err) => {
    console.error("Error de conexión a MongoDB:", err.message);
  });

  mongoose.connection.on("disconnected", () => {
    console.warn("MongoDB desconectado");
  });
}

module.exports = connectDB;