const ApiError = require("../utils/ApiError");

function notFound(req, res, next) {
  next(new ApiError(404, `Ruta no encontrada: ${req.method} ${req.originalUrl}`));
}

function errorHandler(err, req, res, next) {
  let statusCode = err.statusCode || 500;
  let message = err.message || "Error interno del servidor";
  let errors;

  // Validación de Mongoose (required, min/max, match, enum, etc.)
  if (err.name === "ValidationError") {
    statusCode = 400;
    errors = Object.values(err.errors).map((e) => e.message);
    message = "Error de validación";
  }

  // ObjectId con formato inválido
  if (err.name === "CastError") {
    statusCode = 400;
    message = `Id inválido: "${err.value}"`;
  }

  // Clave duplicada (índice unique), ej: email repetido
  if (err.code === 11000) {
    statusCode = 409;
    const field = Object.keys(err.keyValue || {})[0];
    const value = field ? err.keyValue[field] : "";
    message = field
      ? `Ya existe un registro con ${field}: "${value}"`
      : "Registro duplicado";

  }

  if (statusCode === 500 && process.env.NODE_ENV === "production") {
    message = "Error interno del servidor";
  }

  if (statusCode === 500) {
    console.error("[ERROR 500]", err);
  }

  res.status(statusCode).json({
    success: false,
    status: statusCode,
    message,
    ...(errors ? { errors } : {})
  });
}

module.exports = { notFound, errorHandler };