# TaskFlow API

API REST para la gestión de usuarios, equipos y tareas de **TaskFlow**, construida con **Node.js, Express y MongoDB (Mongoose)**, conectada a **MongoDB Atlas**. Usa la misma estructura de datos que el frontend TaskFlow del curso de React, por lo que ambos proyectos se pueden integrar directamente.

## Tecnologías

- Node.js + Express
- MongoDB Atlas + Mongoose
- dotenv (variables de entorno)
- cors

## Estructura del proyecto

```
taskflow-api/
├── config/
│   └── db.js              # Conexión única a MongoDB (pool de conexiones)
├── controllers/
│   ├── userController.js
│   ├── teamController.js
│   └── taskController.js
├── middleware/
│   └── errorHandler.js    # Manejo centralizado de errores (400/404/409/500)
├── models/
│   ├── User.js
│   ├── Team.js
│   └── Task.js
├── routes/
│   ├── userRoutes.js
│   ├── teamRoutes.js
│   └── taskRoutes.js
├── utils/
│   ├── ApiError.js
│   ├── catchAsync.js
│   └── validateObjectId.js
├── app.js                 # Configuración de Express (middlewares y rutas)
├── server.js               # Punto de entrada: conecta a la DB y levanta el servidor
├── requests.http           # Colección de pruebas de todos los endpoints
├── .env.example
└── .gitignore
```

El flujo de una petición es: **ruta (`routes/`) → controlador (`controllers/`) → modelo (`models/`) → MongoDB**, y cualquier error se propaga con `next(err)` hasta el middleware centralizado en `middleware/errorHandler.js`.

## Instalación y ejecución

### 1. Clonar el repositorio

```bash
git clone <url-del-repositorio>
cd taskflow-api
```

### 2. Instalar dependencias

```bash
npm install
```

### 3. Configurar las variables de entorno

Copia el archivo de ejemplo y completa tus propios valores:

```bash
cp .env.example .env
```

Edita `.env` con tu cadena de conexión real de MongoDB Atlas (ver sección siguiente).

### 4. Ejecutar el servidor

**Modo desarrollo** (reinicia automáticamente al guardar cambios, requiere `nodemon`):
```bash
npm run dev
```

**Modo producción:**
```bash
npm start
```

Por defecto el servidor queda disponible en `http://localhost:4000`.

## Variables de entorno

Estas variables van en tu archivo `.env` (nunca se sube al repositorio; está incluido en `.gitignore`). El archivo `.env.example` muestra el formato sin credenciales reales:

| Variable | Descripción | Ejemplo |
|---|---|---|
| `PORT` | Puerto en el que corre el servidor Express | `4000` |
| `MONGODB_URI` | Cadena de conexión de MongoDB Atlas (sin el nombre de la base de datos al final) | `mongodb+srv://usuario:password@cluster.mongodb.net/` |
| `DB_NAME` | Nombre de la base de datos dentro del clúster | `tasksflow` |
| `NODE_ENV` | Entorno de ejecución | `development` o `production` |

La conexión a MongoDB se realiza **una sola vez** al iniciar el servidor (en `config/db.js`), usando `dbName` explícito y un `maxPoolSize` para reutilizar conexiones entre peticiones, en lugar de abrir una conexión nueva por cada request.

## Modelos de datos

### User
| Campo | Tipo | Validación |
|---|---|---|
| `name` | String | requerido, 2–60 caracteres |
| `email` | String | requerido, único, formato de email válido |
| `role` | String | enum: `admin`, `member` (default `member`) |
| `team` | ObjectId | referencia a `Team` |

### Team
| Campo | Tipo | Validación |
|---|---|---|
| `name` | String | requerido, único, 2–50 caracteres |
| `description` | String | máx. 280 caracteres |
| `members` | [ObjectId] | referencia a `User` |

### Task
| Campo | Tipo | Validación |
|---|---|---|
| `title` | String | requerido, 3–120 caracteres |
| `description` | String | máx. 500 caracteres |
| `status` | String | enum: `todo`, `in-progress`, `done` (default `todo`) |
| `priority` | Number | 1–5 (default 3) |
| `assignedTo` | ObjectId | referencia a `User` |
| `team` | ObjectId | requerido, referencia a `Team` |
| `dueDate` | Date | opcional |

## Endpoints disponibles

### Users — `/api/users`
| Método | Ruta | Descripción |
|---|---|---|
| GET | `/api/users` | Listar todos los usuarios |
| GET | `/api/users/:id` | Obtener un usuario por id |
| POST | `/api/users` | Crear un usuario |
| PUT | `/api/users/:id` | Actualizar un usuario |
| DELETE | `/api/users/:id` | Eliminar un usuario |

### Teams — `/api/teams`
| Método | Ruta | Descripción |
|---|---|---|
| GET | `/api/teams` | Listar todos los equipos |
| GET | `/api/teams/:id` | Obtener un equipo por id |
| POST | `/api/teams` | Crear un equipo |
| PUT | `/api/teams/:id` | Actualizar un equipo |
| DELETE | `/api/teams/:id` | Eliminar un equipo |

### Tasks — `/api/tasks`
| Método | Ruta | Descripción |
|---|---|---|
| GET | `/api/tasks` | Listar tareas, con filtros/orden/paginación |
| GET | `/api/tasks/:id` | Obtener una tarea por id |
| POST | `/api/tasks` | Crear una tarea |
| PUT | `/api/tasks/:id` | Actualizar una tarea |
| DELETE | `/api/tasks/:id` | Eliminar una tarea |
| GET | `/api/tasks/stats/:teamId` | **Consulta avanzada:** cantidad de tareas por status dentro de un equipo (Aggregation Pipeline) |

#### Filtros, orden y paginación en `GET /api/tasks`

```
GET /api/tasks?status=todo&sort=-priority&page=1&limit=10
```

| Query param | Descripción |
|---|---|
| `status` | Filtra por `todo`, `in-progress` o `done` |
| `team` | Filtra por id de equipo |
| `assignedTo` | Filtra por id de usuario responsable |
| `sort` | Campo de orden; usa `-` para descendente (ej: `-priority`, `createdAt`) |
| `page` | Número de página (default `1`) |
| `limit` | Resultados por página, máx. 100 (default `10`) |

## Manejo de errores

Todas las respuestas de error siguen el mismo formato:

```json
{
  "success": false,
  "status": 404,
  "message": "Tarea no encontrada con id: \"...\""
}
```

| Código | Cuándo ocurre |
|---|---|
| `400` | Id con formato inválido, o datos que no pasan las validaciones del modelo (`required`, `enum`, `min/max`, `match`) |
| `404` | El recurso solicitado no existe |
| `409` | Registro duplicado (ej: email o nombre de equipo repetido, por índice `unique`) |
| `500` | Error inesperado del servidor |

## Pruebas de los endpoints

El archivo [`requests.http`](./requests.http) incluye un ejemplo de cada endpoint, listo para ejecutarse con la extensión **REST Client** de VS Code o importarse en **Postman/Thunder Client**. Incluye también ejemplos de los errores `400`, `404` y `409`.

## Integración con el frontend TaskFlow (React)

Esta API usa la misma estructura de datos (`User`, `Team`, `Task`) que el frontend construido durante el curso de React, por lo que las respuestas de estos endpoints pueden consumirse directamente desde ese proyecto sin necesidad de transformar los datos.
