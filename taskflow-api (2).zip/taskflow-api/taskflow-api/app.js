const express = require("express");
const cors = require("cors");

const userRoutes = require("./routes/userRoutes");
const teamRoutes = require("./routes/teamRoutes");
const taskRoutes = require("./routes/taskRoutes");
const { notFound, errorHandler } = require("./middleware/errorHandler");

const app = express();

app.use(cors());
app.use(express.json());

// Healthcheck simple
app.get("/", (req, res) => {
  res.status(200).json({ success: true, message: "TaskFlow API funcionando correctamente" });
});

app.use("/api/users", userRoutes);
app.use("/api/teams", teamRoutes);
app.use("/api/tasks", taskRoutes);

// 404 para rutas no definidas
app.use(notFound);

// Manejo de errores centralizado (siempre al final)
app.use(errorHandler);

module.exports = app;