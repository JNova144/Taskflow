const mongoose = require("mongoose");
const Task = require("../models/Task");
const ApiError = require("../utils/ApiError");
const catchAsync = require("../utils/catchAsync");
const validateObjectId = require("../utils/validateObjectId");

// GET /api/tasks
// Soporta: /api/tasks?status=todo&sort=-priority&page=1&limit=10
const getTasks = catchAsync(async (req, res) => {
  const { status, team, assignedTo, sort, page = 1, limit = 10 } = req.query;

  const filter = {};
  if (status) filter.status = status;
  if (team) filter.team = team;
  if (assignedTo) filter.assignedTo = assignedTo;

  // sort=-priority => { priority: -1 } | sort=createdAt => { createdAt: 1 }
  let sortOption = { createdAt: -1 };
  if (sort) {
    const direction = sort.startsWith("-") ? -1 : 1;
    const field = sort.replace(/^-/, "");
    sortOption = { [field]: direction };
  }

  const pageNum = Math.max(parseInt(page, 10) || 1, 1);
  const limitNum = Math.min(Math.max(parseInt(limit, 10) || 10, 1), 100);
  const skip = (pageNum - 1) * limitNum;

  const [tasks, total] = await Promise.all([
    Task.find(filter)
      .populate("assignedTo", "name email")
      .populate("team", "name")

      .sort(sortOption)
      .skip(skip)
      .limit(limitNum),
    Task.countDocuments(filter)
  ]);

  res.status(200).json({
    success: true,
    status: 200,
    count: tasks.length,
    total,
    page: pageNum,
    totalPages: Math.ceil(total / limitNum) || 1,
    data: tasks
  });
});

// GET /api/tasks/:id
const getTaskById = catchAsync(async (req, res) => {
  validateObjectId(req.params.id);

  const task = await Task.findById(req.params.id)
    .populate("assignedTo", "name email")
    .populate("team", "name");

  if (!task) {
    throw new ApiError(404, `Tarea no encontrada con id: "${req.params.id}"`);
  }

  res.status(200).json({ success: true, status: 200, data: task });
});


// POST /api/tasks
const createTask = catchAsync(async (req, res) => {
  const { title, description, status, priority, assignedTo, team, dueDate } = req.body;

  const task = await Task.create({ title, description, status, priority, assignedTo, team, dueDate });

  res.status(201).json({ success: true, status: 201, data: task });
});

// PUT /api/tasks/:id
const updateTask = catchAsync(async (req, res) => {
  validateObjectId(req.params.id);

  const { title, description, status, priority, assignedTo, team, dueDate } = req.body;

  const task = await Task.findByIdAndUpdate(
    req.params.id,
    { title, description, status, priority, assignedTo, team, dueDate },
    { new: true, runValidators: true, context: "query" }
  );

  if (!task) {
    throw new ApiError(404, `Tarea no encontrada con id: "${req.params.id}"`);
  }

  res.status(200).json({ success: true, status: 200, data: task });
});

// DELETE /api/tasks/:id
const deleteTask = catchAsync(async (req, res) => {
  validateObjectId(req.params.id);


  const task = await Task.findByIdAndDelete(req.params.id);
  if (!task) {
    throw new ApiError(404, `Tarea no encontrada con id: "${req.params.id}"`);
  }

  res.status(200).json({ success: true, status: 200, message: "Tarea eliminada", data: task });
});

// GET /api/tasks/stats/:teamId
// Consulta avanzada con Aggregation Pipeline: tareas por status dentro de un equipo
const getTaskStatsByTeam = catchAsync(async (req, res) => {
  const { teamId } = req.params;
  validateObjectId(teamId);

  const stats = await Task.aggregate([
    { $match: { team: new mongoose.Types.ObjectId(teamId) } },
    { $group: { _id: "$status", total: { $sum: 1 } } },
    { $sort: { total: -1 } }
  ]);

  res.status(200).json({ success: true, status: 200, team: teamId, data: stats });
});

module.exports = {
  getTasks,
  getTaskById,
  createTask,
  updateTask,
  deleteTask,
  getTaskStatsByTeam
};