const Team = require("../models/Team");
const ApiError = require("../utils/ApiError");
const catchAsync = require("../utils/catchAsync");
const validateObjectId = require("../utils/validateObjectId");

// GET /api/teams
const getTeams = catchAsync(async (req, res) => {
  const teams = await Team.find().populate("members", "name email role").sort({ createdAt: -1 });
  res.status(200).json({ success: true, status: 200, count: teams.length, data: teams });
});

// GET /api/teams/:id
const getTeamById = catchAsync(async (req, res) => {
  validateObjectId(req.params.id);

  const team = await Team.findById(req.params.id).populate("members", "name email role");
  if (!team) {
    throw new ApiError(404, `Equipo no encontrado con id: "${req.params.id}"`);
  }

  res.status(200).json({ success: true, status: 200, data: team });
});

// POST /api/teams
const createTeam = catchAsync(async (req, res) => {
  const { name, description, members } = req.body;

  const team = await Team.create({ name, description, members });

  res.status(201).json({ success: true, status: 201, data: team });
});

// PUT /api/teams/:id
const updateTeam = catchAsync(async (req, res) => {
  validateObjectId(req.params.id);

  const { name, description, members } = req.body;

  const team = await Team.findByIdAndUpdate(
    req.params.id,
    { name, description, members },
    { new: true, runValidators: true, context: "query" }
  );

  if (!team) {
    throw new ApiError(404, `Equipo no encontrado con id: "${req.params.id}"`);
  }

  res.status(200).json({ success: true, status: 200, data: team });
});

// DELETE /api/teams/:id
const deleteTeam = catchAsync(async (req, res) => {
  validateObjectId(req.params.id);

  const team = await Team.findByIdAndDelete(req.params.id);
  if (!team) {
    throw new ApiError(404, `Equipo no encontrado con id: "${req.params.id}"`);
  }

  res.status(200).json({ success: true, status: 200, message: "Equipo eliminado", data: team });
});

module.exports = { getTeams, getTeamById, createTeam, updateTeam, deleteTeam };