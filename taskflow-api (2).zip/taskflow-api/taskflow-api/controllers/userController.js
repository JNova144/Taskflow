const User = require("../models/User");
const ApiError = require("../utils/ApiError");
const catchAsync = require("../utils/catchAsync");
const validateObjectId = require("../utils/validateObjectId");

// GET /api/users
const getUsers = catchAsync(async (req, res) => {
  const users = await User.find().populate("team", "name").sort({ createdAt: -1 });
  res.status(200).json({ success: true, status: 200, count: users.length, data: users });
});

// GET /api/users/:id
const getUserById = catchAsync(async (req, res) => {
  validateObjectId(req.params.id);

  const user = await User.findById(req.params.id).populate("team", "name");
  if (!user) {
    throw new ApiError(404, `Usuario no encontrado con id: "${req.params.id}"`);
  }

  res.status(200).json({ success: true, status: 200, data: user });
});

// POST /api/users
const createUser = catchAsync(async (req, res) => {
  const { name, email, role, team } = req.body;

  const user = await User.create({ name, email, role, team });

  res.status(201).json({ success: true, status: 201, data: user });
});


// PUT /api/users/:id
const updateUser = catchAsync(async (req, res) => {
  validateObjectId(req.params.id);

  const { name, email, role, team } = req.body;

  const user = await User.findByIdAndUpdate(
    req.params.id,
    { name, email, role, team },
    { new: true, runValidators: true, context: "query" }
  );

  if (!user) {
    throw new ApiError(404, `Usuario no encontrado con id: "${req.params.id}"`);
  }

  res.status(200).json({ success: true, status: 200, data: user });
});

// DELETE /api/users/:id
const deleteUser = catchAsync(async (req, res) => {
  validateObjectId(req.params.id);

  const user = await User.findByIdAndDelete(req.params.id);
  if (!user) {
    throw new ApiError(404, `Usuario no encontrado con id: "${req.params.id}"`);
  }

  res.status(200).json({ success: true, status: 200, message: "Usuario eliminado", data: user });
});

module.exports = { getUsers, getUserById, createUser, updateUser, deleteUser };