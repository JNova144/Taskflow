const express = require("express");
const {
  getTasks,
  getTaskById,
  createTask,
  updateTask,
  deleteTask,
  getTaskStatsByTeam
} = require("../controllers/taskController");

const router = express.Router();

// Esta ruta específica va ANTES de "/:id" para que "stats" no se interprete como un id
router.get("/stats/:teamId", getTaskStatsByTeam);

router.get("/", getTasks);
router.get("/:id", getTaskById);
router.post("/", createTask);
router.put("/:id", updateTask);
router.delete("/:id", deleteTask);

module.exports = router;