const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "El nombre es obligatorio"],
      trim: true,
      minlength: [2, "El nombre debe tener al menos 2 caracteres"],
      maxlength: [60, "El nombre no puede superar los 60 caracteres"]
    },
    email: {
      type: String,
      required: [true, "El email es obligatorio"],
      unique: true,
      lowercase: true,
      trim: true,
      match: [
        /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
        "El email no tiene un formato válido"
      ]
    },
    role: {
      type: String,
      enum: {
        values: ["admin", "member"],
        message: "El rol debe ser 'admin' o 'member'"
      },
      default: "member"
    },
    team: {
      type: mongoose.Schema.Types.ObjectId,

      ref: "Team",
      default: null
    }
  },
  { timestamps: true }
);

module.exports = mongoose.model("User", userSchema);