const mongoose = require("mongoose");

const taskSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, "El título de la tarea es obligatorio"],
      trim: true,
      minlength: [3, "El título debe tener al menos 3 caracteres"],
      maxlength: [120, "El título no puede superar los 120 caracteres"]
    },
    description: {
      type: String,
      trim: true,
      maxlength: [500, "La descripción no puede superar los 500 caracteres"],
      default: ""
    },
    status: {
      type: String,
      enum: {
        values: ["todo", "in-progress", "done"],
        message: "El status debe ser 'todo', 'in-progress' o 'done'"
      },
      default: "todo"
    },
    priority: {
      type: Number,
      min: [1, "La prioridad mínima es 1"],
      max: [5, "La prioridad máxima es 5"],
      default: 3
    },
    assignedTo: {

      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null
    },
    team: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Team",
      required: [true, "La tarea debe pertenecer a un equipo"]
    },
    dueDate: {
      type: Date,
      default: null
    }
  },
  { timestamps: true }
);

taskSchema.index({ team: 1, status: 1 });
taskSchema.index({ priority: -1 });

module.exports = mongoose.model("Task", taskSchema);